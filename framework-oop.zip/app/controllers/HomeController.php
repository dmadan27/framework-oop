<?php
	/**
	* 
	*/
	class Home{

		public function __construct(){
			echo "Selamat Datang di Class Home <br>";
		}

		public function index(){

		}
	}